/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'font', 'gu', {
	fontSize: {
		label: 'ફૉન્ટ સાઇઝ/કદ',
		voiceLabel: 'ફોન્ટ સાઈઝ',
		panelTitle: 'ફૉન્ટ સાઇઝ/કદ'
	},
	label: 'ફૉન્ટ',
	panelTitle: 'ફૉન્ટ',
	voiceLabel: 'ફોન્ટ'
} );
